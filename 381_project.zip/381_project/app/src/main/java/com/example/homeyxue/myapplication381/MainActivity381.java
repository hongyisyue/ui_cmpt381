package com.example.homeyxue.myapplication381;

import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity381 extends AppCompatActivity {

    public Button button1;
    public TextView textView1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main381);

        textView1 = (TextView) findViewById(R.id.label1);
        button1 = (Button) findViewById(R.id.button1);
        button1.setOnClickListener(greeting());
    }
    private View.OnClickListener greeting() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleClick(v);
            }
        };
    }

    public void handleClick(View v) {
        textView1.setText("Hello 381!");
    }
}
