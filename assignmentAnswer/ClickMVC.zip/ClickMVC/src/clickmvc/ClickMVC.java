/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clickmvc;

import java.util.ArrayList;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.text.Font;
import javafx.stage.Stage;

/**
 *
 * @author gutwin
 */
public class ClickMVC extends Application {
    
    @Override
    public void start(Stage primaryStage) {
        SModel model = new SModel();
        SView view = new SView();
        SController controller = new SController();
        model.addSubscriber(view);
        controller.setModel(model);
        
        view.setOnMouseClicked(controller::handleClick);
             
        Scene scene = new Scene(view);
        
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
    class SModel {
        int clicks;
        ArrayList<ModelListener> subs = new ArrayList<>();
        
        public void addSubscriber(ModelListener aSub) {
            subs.add(aSub);
        }
        
        public void addClick() {
            clicks++;
            subs.forEach(s -> s.modelChanged(clicks));
        }
    }
    
    interface ModelListener {
        public void modelChanged(int clicks);
    }
    
    class SView extends Pane implements ModelListener {
        Label display;
        
        public SView() {
            display = new Label("Clicks: 0");
            display.setFont(new Font(24));
            getChildren().add(display);
        }
        
        public void modelChanged(int clicks) {
            display.setText("Clicks: " + clicks);
        }
    }
    
    class SController {
        SModel model;
        
        public void setModel(SModel aModel) {
            model = aModel;
        }
        
        public void handleClick(MouseEvent event) {
            model.addClick();
        }
    }
}
