/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package barcontroldemo;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;

/**
 *
 * @author gutwin
 */
public class BarControlDemo extends Application {

    BarControl bc1, bc2, bc3;
    Label output1, output2, output3;

    @Override
    public void start(Stage primaryStage) {
        // part 1
        Button quitButton = new Button("Quit");
        Slider range = new Slider(150, 1000, 275);
        Label sliderOutput = new Label("275.0");
        sliderOutput.fontProperty().set(Font.font(24));
        range.valueProperty().addListener(
                (ObservableValue<? extends Number> ov, Number oldVal, Number newVal) -> {
                    sliderOutput.setText(String.format("%.1f", newVal));
                });
        quitButton.setOnAction(event -> {
            System.out.println("Goodbye!");
            Platform.exit();
        });

        bc1 = new BarControl(100, 500, 200);
        bc1.valueProperty().addListener(this::handleChange1);
        output1 = new Label("200.0");
        output1.fontProperty().set(Font.font(24));

        bc2 = new BarControl(100, 500, 200);
        output2 = new Label("200.0");
        output2.fontProperty().set(Font.font(24));
        output2.textProperty().bind(bc2.valueProperty().asString("%.1f"));

        bc3 = new BarControl(100, 500, 200);
        bc3.valueProperty().addListener(this::handleChange3);
        output3 = new Label("200.0");
        output3.fontProperty().set(Font.font(24));

        VBox root = new VBox();
        HBox bars = new HBox();
        bars.getChildren().add(bc1);
        bars.getChildren().add(output1);
        bars.getChildren().add(bc2);
        bars.getChildren().add(output2);
        bars.getChildren().add(bc3);
        bars.getChildren().add(output3);
        root.getChildren().add(bars);
        root.getChildren().add(range);
        root.getChildren().add(sliderOutput);
        root.getChildren().add(quitButton);

        Scene scene = new Scene(root);
        primaryStage.setTitle("381 Custom Widgets");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public void handleChange1(ObservableValue<? extends Number> ov, Number oldVal, Number newVal) {
        output1.setText(String.format("%.1f", bc1.getValue()));
    }

    public void handleChange3(ObservableValue<? extends Number> ov, Number oldVal, Number newVal) {
        output3.setText(String.format("%.1f", newVal));
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

}
