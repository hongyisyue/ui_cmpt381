/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package barcontroldemo;

import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;

/**
 *
 * @author gutwin
 */
public class BarControl extends Pane {
    
    private double min, max;
    private double range;
    //private double minX, maxX;
    private DoubleProperty value = new SimpleDoubleProperty(); // value in the widget's defined range
    double height, width;
    //boolean changing;
    GraphicsContext gc;
    double inset;
    private double barY;
    private double maxY, minY, rangeY;
    
    public BarControl(double newMin, double newMax, double newValue) {
        min = newMin;
        max = newMax;
        range = max - min;
        setValue(newValue);
        width = 50;
        height = 200;
        //changing = false;
        inset = 5;
        maxY = height - inset;
        minY = inset;
        rangeY = maxY - minY;
        
        StackPane root = new StackPane();
        Canvas widgetCanvas = new Canvas(width, height);
        root.getChildren().add(widgetCanvas);
        gc = widgetCanvas.getGraphicsContext2D();

        widgetCanvas.setOnMousePressed(this::handleMousePressed);
        widgetCanvas.setOnMouseDragged(this::handleMouseDragged);
        widgetCanvas.setOnMouseReleased(this::handleMouseReleased);

        drawShapes();
        getChildren().add(root);
    }

    public void drawShapes() {
        // blank background
        gc.setFill(Color.BLACK);
        gc.fillRect(0, 0, width, height);
        // draw widget rectangle
        gc.setFill(Color.YELLOW);
        double fraction = (getValue() - min) / range;
        barY = height - (rangeY * fraction + inset);
        // always draw at least one pixel
        if (barY >= height - inset) {
            barY = height - inset - 1;
        }
        //barTop = height-inset*2 - ((getValue() - min) / range * height);
        gc.fillRect(inset, barY, width - 2*inset, height - inset - barY);
    }

    public void handleMousePressed(MouseEvent e) {
        //changing = true;
        drawShapes();
    }

    public void handleMouseDragged(MouseEvent e) {
        // bar pixels can't go below min or above max
        double y = e.getY();
        if (y > maxY) y = maxY;
        if (y < minY) y = minY;
        
        double fraction = 1 - (y - inset) / rangeY;
        setValue(fraction * range + min);
        //System.out.println(y + "," + fraction + "," + getValue());
        drawShapes();
    }

    public void handleMouseReleased(MouseEvent e) {
        //changing = false;
        drawShapes();
    }

    public final void setValue(double d) {
        valueProperty().set(d);
    }
    
    public final double getValue() {
        //System.out.println(value.get());
        return value.get();
    }

    public final DoubleProperty valueProperty() {
        return value;
    }
}
