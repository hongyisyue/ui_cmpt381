package com.example.gutwin.layoutsimulator;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.Log;

/**
 * Created by gutwin on 2018-01-21.
 */

public class XButton extends XWidget {
    //int id;
    //float x,y;
    //float width,height;
    //float prefWidth,prefHeight;
    String text;
    boolean selected = false;

    public XButton(int newID, float newPW, float newPH, String newText) {
        id = newID;
        //x = newX;
        //y = newY;
        prefWidth = newPW;
        prefHeight = newPH;
        width = prefWidth;
        height = prefHeight;
        text = newText;
    }

    public XButton(int newID, float newX, float newY, float newPW, float newPH, String newText) {
        id = newID;
        x = newX;
        y = newY;
        prefWidth = newPW;
        prefHeight = newPH;
        width = prefWidth;
        height = prefHeight;
        text = newText;
    }

    void addChild(XWidget xw) {
        // shouldn't be adding children to a button...
    }

    XWidget contains(float cx, float cy) {
        if (cx >= x && cx <= x + width && cy >= y && cy <= y + height) {
            return this;
        } else {
            return null;
        }
    }

    void layout(float left, float top, float parentWidth, float parentHeight) {
        // set my size
        // first check whether there is more room than my preferred size
        float realWidth = parentWidth - insets*2;
        if (realWidth > prefWidth) {
            x = left + parentWidth/2 - prefWidth/2;
            width = prefWidth;
        } else {
            // use it all because parent is smaller than we want
            x = left + insets;
            width = realWidth;
        }
        float realHeight = parentHeight - insets*2;
        if (realHeight > prefHeight) {
            y = top + parentHeight/2 - prefHeight/2;
            height = prefHeight;
        } else {
            // use it all as parent is too small
            y = top + insets;
            height = realHeight;
        }
        Log.d("LAYOUT","Button " + id + " has position " + x + "," + y + " and size " + width + "," + height);
    }

    void draw(float left, float top, Canvas myCanvas, Paint myPaint) {
        // left and top are what to add to my x and y,
        // since my x and y are relative to my parent.

        myPaint.setTextSize(50);
        myPaint.setTextAlign(Paint.Align.CENTER);
        myPaint.setColor(Color.rgb(100,150,255));
        myPaint.setStyle(Paint.Style.FILL);
        float canvasX = x + left;
        float canvasY = y + top;
        myCanvas.drawRect(canvasX, canvasY,canvasX + width,canvasY + height,myPaint);
        if (selected) {
            myPaint.setColor(Color.RED);
        } else {
            myPaint.setColor(Color.BLACK);
        }
        myPaint.setStyle(Paint.Style.STROKE);
        myCanvas.drawRect(canvasX, canvasY,canvasX + width,canvasY + height,myPaint);
        myPaint.setColor(Color.BLACK);
        myCanvas.drawText(text, canvasX+width/2,canvasY+height/2+20,myPaint);
    }
}
