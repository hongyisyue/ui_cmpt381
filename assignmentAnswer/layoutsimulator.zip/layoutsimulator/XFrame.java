package com.example.gutwin.layoutsimulator;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.Log;

import java.util.ArrayList;

/**
 * Created by gutwin on 2018-01-21.
 */

public class XFrame extends XWidget {

    public enum Orientation {
        HORIZONTAL, VERTICAL
    }
    Orientation orient = Orientation.HORIZONTAL;

    public XFrame(int newID) {
        id = newID;
        children = new ArrayList<>();
    }

    void addChild(XWidget xw) {
        children.add(xw);
    }

    XWidget contains(float cx, float cy) {
        XWidget found = null;
        for (XWidget xw : children) {
            found = xw.contains(cx,cy);
            if (found != null) {
                break;
            }
        }
        return found;
    }

    void setOrientation(Orientation o) {
        orient = o;
    }

    void layout(float left, float top, float parentWidth, float parentHeight) {
        // set my size
        x = left;
        y = top;
        width = parentWidth;
        height = parentHeight;
        Log.d("LAYOUT","Frame " + id + " has position " + x + "," + y + " and size " + width + "," + height);


        // if I have children, divide my space equally among them
        // (later, only divide up to my preferred size)
        if (!children.isEmpty()) {
            if (orient == Orientation.HORIZONTAL) {
                // go along width with same heights
                float childWidth = parentWidth / children.size();
                float childLeft = 0;
                for (XWidget xw : children) {
                    xw.layout(childLeft+left,top,childWidth,parentHeight);
                    childLeft += childWidth;
                }
            }
            if (orient == Orientation.VERTICAL) {
                // go along height with same widths
                float childHeight = parentHeight / children.size();
                float childTop = 0;
                for (XWidget xw : children) {
                    xw.layout(left,childTop+top,parentWidth,childHeight);
                    childTop += childHeight;
                }
            }
        }
    }

    void draw(float left, float top, Canvas myCanvas, Paint myPaint) {
        // left and top are what to add to my x and y,
        // since my x and y are relative to my parent.

        //myPaint.setColor(Color.rgb((int)(Math.random()*100),(int)(Math.random()*100), (int)(Math.random()*100)));
        myPaint.setColor(Color.rgb(0,255,0));
        myPaint.setStyle(Paint.Style.FILL);
        float canvasX = x + left;
        float canvasY = y + top;
        myCanvas.drawRect(canvasX, canvasY,canvasX + width,canvasY + height,myPaint);
        myPaint.setColor(Color.BLACK);
        myPaint.setStyle(Paint.Style.STROKE);
        myCanvas.drawRect(canvasX, canvasY,canvasX + width,canvasY + height,myPaint);

        // now draw children on top
        for (XWidget xw : children) {
            xw.draw(left, top, myCanvas, myPaint);
        }
    }
}
