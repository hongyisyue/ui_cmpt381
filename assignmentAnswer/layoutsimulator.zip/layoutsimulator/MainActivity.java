package com.example.gutwin.layoutsimulator;

import android.app.Activity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity implements View.OnTouchListener{

    LayoutView lv1;
    XWidget selected;
    EditText prefWidthField, prefHeightField, insetsField, alignField;
    TextView idField;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        LinearLayout root = findViewById(R.id.linear1);
        prefWidthField = findViewById(R.id.textView19);
        prefHeightField = findViewById(R.id.textView21);
        insetsField = findViewById(R.id.textView9);
        alignField = findViewById(R.id.textView11);
        idField = findViewById(R.id.textView7);
        lv1 = new LayoutView(this, null);
        Button setButton = new Button(this);
        setButton.setText("Set Values");
        root.addView(setButton);
        setButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setValuesForSelected();
            }
        });
        root.addView(lv1);
        lv1.setOnTouchListener(this);
    }

    void setValuesForSelected() {
        float pw = Float.parseFloat(prefWidthField.getText().toString());
        float ph = Float.parseFloat(prefHeightField.getText().toString());
        float in = Float.parseFloat(insetsField.getText().toString());
        String al = alignField.getText().toString();

        if (selected != null) {
            selected.prefWidth = pw;
            selected.prefHeight = ph;
            selected.insets = in;
            if (al.equals("L")) {
                selected.align = XWidget.Alignment.LEFT;
            } else if (al.equals("R")) {
                selected.align = XWidget.Alignment.RIGHT;
            } else {
                selected.align = XWidget.Alignment.CENTER;
            }
        }
        lv1.invalidate();
    }

    @Override
    public boolean onTouch(View v, MotionEvent event) {

        //if (event.getX() >= 100 && event.getX() <= 400 && event.getY() >= 300 && event.getY() <= 500) {
        //prefWidthField.setText("click!");
        //}

        selected = lv1.checkHit(event.getX(),event.getY());
        if (selected != null) {
            idField.setText("#" + selected.id);
            insetsField.setText(""+selected.insets);
            if (selected.align == XWidget.Alignment.CENTER) {
                alignField.setText("C");
            } else if (selected.align == XWidget.Alignment.LEFT) {
                alignField.setText("L");
            } else if (selected.align == XWidget.Alignment.RIGHT) {
                alignField.setText("R");
            } else {
                alignField.setText("ERR");
            }
            prefHeightField.setText(""+selected.prefHeight);
            prefWidthField.setText(""+selected.prefWidth);
        }

        lv1.invalidate();
        return false;
    }
}
