package com.example.gutwin.layoutsimulator;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

/**
 * Created by gutwin on 2018-01-21.
 */

public class LayoutView extends View {
    //Canvas layoutCanvas;
    Paint myPaint;
    String sample;
    XFrame root;

    public LayoutView(Context context, AttributeSet attrs) {
        super(context, attrs);
        //layoutCanvas = new Canvas();
        sample = new String("sample text");
        setBackgroundColor(Color.rgb(50,20,80));
        myPaint = new Paint();

        // ****************************
        // START LAYOUT SIMULATION
        // ****************************

        root = new XFrame(1);
        root.setOrientation(XFrame.Orientation.HORIZONTAL);
        root.insets = 0;

        XFrame vert1 = new XFrame(2);
        vert1.setOrientation(XFrame.Orientation.VERTICAL);
        vert1.insets = 0;

        XFrame horiz1 = new XFrame(8);
        horiz1.setOrientation(XFrame.Orientation.HORIZONTAL);
        horiz1.insets = 0;

        XButton xb1 = new XButton(3,200,100,"Button1");
        xb1.insets = 15;
        XButton xb2 = new XButton(4,100,100,"Button2");
        xb2.insets = 15;
        XButton xb3 = new XButton(5,300,100,"Button3");
        xb3.insets = 15;
        XButton xb4 = new XButton(6,300,100,"Button4");
        xb4.insets = 15;
        XButton xb5 = new XButton(7,300,100,"Button5");
        xb5.insets = 15;
        XButton xb6 = new XButton(9,300,100,"Button6");
        xb6.insets = 15;
        XButton xb7 = new XButton(10,300,100,"Button7");
        xb7.insets = 15;

        vert1.addChild(xb1);
        vert1.addChild(xb3);
        vert1.addChild(horiz1);
        horiz1.addChild(xb2);
        horiz1.addChild(xb6);
        horiz1.addChild(xb7);
        root.addChild(xb4);
        root.addChild(vert1);
        root.addChild(xb5);

        // ****************************
        // END LAYOUT SIMULATION
        // ****************************
    }

    public void layout() {

    }

    protected void onDraw2(Canvas myCanvas) {
        myPaint.setColor(Color.GREEN);
        myPaint.setStyle(Paint.Style.FILL);
        myCanvas.drawRect(100,300,400,500,myPaint);
    }

    protected void onDraw(Canvas myCanvas) {
        root.layout(0,0, this.getWidth(), this.getHeight());
        root.draw(0,0,myCanvas, myPaint);
        //myPaint.setColor(Color.WHITE);
        //myPaint.setTextSize(50);
        //myCanvas.drawText(sample, 300,600,myPaint);
    }

    public XWidget checkHit (float cx, float cy) {
        return root.contains(cx,cy);
    }

//    public XWidget getXWidgetAt (float x, float y) {
//        XWidget hit = null;
//        for (XWidget xw : root.children) {
//            if (xw.contains(x,y)) {
//                hit = xw;
//                break;
//            }
//        }
//        return hit;
//    }
}
