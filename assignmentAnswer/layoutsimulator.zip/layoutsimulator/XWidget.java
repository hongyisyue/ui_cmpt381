package com.example.gutwin.layoutsimulator;

import android.graphics.Canvas;
import android.graphics.Paint;

import java.util.ArrayList;

/**
 * Created by gutwin on 2018-01-21.
 */

public abstract class XWidget {
    int id;
    float x,y;
    float width,height;
    float prefWidth,prefHeight;
    float insets;
    ArrayList<XWidget> children;

    public enum Alignment {
        LEFT, CENTER, RIGHT
    }
    Alignment align = Alignment.CENTER;


    public XWidget() {
        id = 0;
        children = new ArrayList<>();
    }

    void setInsets(float newIn) {
        insets = newIn;
    }

    abstract void addChild(XWidget xw);

    abstract void layout(float left, float top, float parentWidth, float parentHeight);

    abstract void draw(float left, float top, Canvas myCanvas, Paint myPaint);

    abstract XWidget contains(float touchX, float touchY);
}
