package graphdemo;

import javafx.scene.input.MouseEvent;

public class RadarViewController {

    RadarView view;
    InteractionModel iModel;

    int state;
    final int STATE_READY = 0;
    final int STATE_DRAGGING = 1;

    double modelX, modelY;
    double prevModelX, prevModelY;
    double modelDX, modelDY;

    double touchX, touchY;
    double prevTouchX, prevTouchY;
    double touchDX, touchDY;

    public RadarViewController() {
        state = STATE_READY;
    }

    public void setView(RadarView mgv) {
        view = mgv;
    }

    public void setInteractionModel(InteractionModel anIModel) {
        iModel = anIModel;
    }

    private void setMovementValues(MouseEvent event) {
        // in view coordinates:
        touchX = event.getX();
        touchY = event.getY();
        touchDX = touchX - prevTouchX;
        touchDY = touchY - prevTouchY;
        prevTouchX = touchX;
        prevTouchY = touchY;
        // in model coordinates:
        modelDX = touchDX / view.logicalWidth;
        modelDY = touchDY / view.logicalHeight;
        modelX = touchX / view.logicalWidth;
        modelY = touchY / view.logicalHeight;
    }

    public void handleMousePressed(MouseEvent event) {
        setMovementValues(event);

        switch (state) {
            case STATE_READY:
                // is click on view rectangle
                if (iModel.inViewport(modelX, modelY)) {
                    state = STATE_DRAGGING;
                }
                break;
        }
    }

    public void handleMouseDragged(MouseEvent event) {
        setMovementValues(event);
        switch (state) {
            case STATE_DRAGGING:
                // move viewport
                iModel.moveViewport(modelDX * -1, modelDY * -1);
                break;
        }
    }

    public void handleMouseReleased(MouseEvent event) {
        state = STATE_READY;
    }
}
