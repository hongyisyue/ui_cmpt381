package graphdemo;

import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.TextAlignment;

public abstract class GraphView extends Pane implements GraphModelListener {

    Canvas graphCanvas;
    GraphicsContext gc;
    Graph model;
    InteractionModel iModel;

    double logicalWidth;
    double logicalHeight;

    public GraphView(double newWidth, double newHeight) {
        graphCanvas = new Canvas(newWidth, newHeight);
        gc = graphCanvas.getGraphicsContext2D();
        this.getChildren().add(graphCanvas);

        logicalWidth = newWidth;
        logicalHeight = newHeight;
    }

    public void setModel(Graph aModel) {
        model = aModel;
    }

    public void setInteractionModel(InteractionModel anIModel) {
        iModel = anIModel;
    }

    public void draw() {
        drawGraph(iModel.portX, iModel.portY);
    }

    public void drawGraph(double shiftX, double shiftY) {
        // draw edges
        model.edges.forEach(edge -> drawEdge(edge, shiftX, shiftY));

        // draw temporary edge if there is one
        drawTemporaryEdge(shiftX, shiftY);

        // draw vertices
        model.vertices.forEach(vertex -> drawVertex(vertex, shiftX, shiftY));
    }

    private void drawVertex(Vertex v, double shiftX, double shiftY) {
        // model coordinates are 0.0 - 1.0, convert to view coordinates
        double vertexLeft = (v.x - v.radius) * logicalWidth - shiftX * logicalWidth;
        double vertexTop = (v.y - v.radius) * logicalHeight - shiftY * logicalHeight;
        double vertexWidth = v.radius * 2 * logicalWidth;
        double vertexHeight = v.radius * 2 * logicalHeight;

        if (v == iModel.selected) {
            // draw selected vertex in orange
            gc.setFill(Color.ORANGE);
            gc.fillOval(vertexLeft, vertexTop, vertexWidth, vertexHeight);
        } else {
            // draw regular vertices in blue
            gc.setLineWidth(1);
            gc.setFill(Color.LIGHTBLUE);
            gc.fillOval(vertexLeft, vertexTop, vertexWidth, vertexHeight);
        }
        if (v == iModel.edgeSource) {
            // if vertex is starting an edge, draw thicker border
            gc.setFill(Color.BLACK);
            gc.setLineWidth(3);
            gc.strokeOval(vertexLeft, vertexTop, vertexWidth, vertexHeight);
        } else {
            gc.setLineWidth(1);
            gc.setFill(Color.BLACK);
            gc.strokeOval(vertexLeft, vertexTop, vertexWidth, vertexHeight);
        }

        // label (id number)
        gc.setTextAlign(TextAlignment.CENTER);
        double fontSize = logicalWidth / 50;
        gc.setFont(new Font(fontSize));
        gc.setFill(Color.BLACK);
        gc.fillText("" + v.id, vertexLeft + vertexWidth / 2, vertexTop + vertexHeight / 2 + fontSize/2);
    }

    private void drawEdge(Edge e, double shiftX, double shiftY) {
        double x1 = e.start.x * logicalWidth - shiftX * logicalWidth;
        double y1 = e.start.y * logicalHeight - shiftY * logicalHeight;
        double x2 = e.end.x * logicalWidth - shiftX * logicalWidth;
        double y2 = e.end.y * logicalHeight - shiftY * logicalHeight;

        gc.setStroke(Color.BLACK);
        gc.setLineWidth(1);
        gc.strokeLine(x1, y1, x2, y2);
    }

    private void drawTemporaryEdge(double shiftX, double shiftY) {
        if (iModel.edgeSource != null) {
            double x1 = iModel.edgeSource.x * logicalWidth - shiftX * logicalWidth;
            double y1 = iModel.edgeSource.y * logicalHeight - shiftY * logicalHeight;
            double x2 = iModel.lineEndX * logicalWidth - shiftX * logicalWidth;
            double y2 = iModel.lineEndY * logicalHeight - shiftY * logicalHeight;
            gc.setStroke(Color.BLACK);
            gc.setLineWidth(3);
            gc.strokeLine(x1, y1, x2, y2);
        }
    }

    public void modelChanged() {
        draw();
    }
}
