package graphdemo;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

public class GraphDemo extends Application {

    @Override
    public void start(Stage primaryStage) {
        // Set up MVC components
        DetailView mainView = new DetailView(500,500,1000,1000);
        DetailViewController mainController = new DetailViewController();
        RadarViewController miniController = new RadarViewController();
        Graph model = new Graph();
        RadarView miniView = new RadarView(100, 100);
        InteractionModel iModel = new InteractionModel();

        // Set up connections between M,V,C
        mainView.setModel(model);
        mainView.setInteractionModel(iModel);
        mainController.setModel(model);
        mainController.setInteractionModel(iModel);
        mainController.setView(mainView);
        model.addSubscriber(mainView);
        iModel.addSubscriber(mainView);

        miniView.setModel(model);
        miniView.setInteractionModel(iModel);
        miniController.setInteractionModel(iModel);
        miniController.setView(miniView);
        model.addSubscriber(miniView);
        iModel.addSubscriber(miniView);
        
        // Event handling
        mainView.setOnMousePressed(mainController::handleMousePressed);
        mainView.setOnMouseReleased(mainController::handleMouseReleased);
        mainView.setOnMouseDragged(mainController::handleMouseDragged);
        miniView.setOnMousePressed(miniController::handleMousePressed);
        miniView.setOnMouseDragged(miniController::handleMouseDragged);
        miniView.setOnMouseReleased(miniController::handleMouseReleased);

        // layout
        StackPane root = new StackPane();
        StackPane.setAlignment(mainView, Pos.TOP_LEFT);
        StackPane.setAlignment(miniView, Pos.TOP_LEFT);
        root.getChildren().add(mainView);
        root.getChildren().add(miniView);
        miniView.setPickOnBounds(false);

        Scene scene = new Scene(root, 500, 500);

        primaryStage.setTitle("Graph Demo!");
        primaryStage.setScene(scene);
        primaryStage.show();

        mainView.draw();
        miniView.draw();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
}
