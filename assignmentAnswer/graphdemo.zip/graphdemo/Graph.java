package graphdemo;

import java.util.ArrayList;

public class Graph {

    ArrayList<Vertex> vertices;
    ArrayList<Edge> edges;
    ArrayList<GraphModelListener> subscribers;
    int nextID;

    public Graph() {
        vertices = new ArrayList<>();
        edges = new ArrayList<>();
        subscribers = new ArrayList<>();
        nextID = 0;
    }

    public void createVertex(double x, double y) {
        vertices.add(new Vertex(x, y, nextID));
        nextID++;
        notifySubscribers();
    }

    public void createEdge(Vertex start, Vertex end) {
        edges.add(new Edge(start, end));
        notifySubscribers();
    }

    public void moveVertex(Vertex v, double dx, double dy) {
        v.move(dx, dy);
        notifySubscribers();
    }

    public Vertex findClick(double x, double y) {
        return vertices.stream()
                .filter(v -> v.contains(x, y))
                .findFirst()
                .orElse(null);
    }

    public boolean contains(double x, double y) {
        return vertices.stream()
                .anyMatch(v -> v.contains(x, y));
    }

    // deletion is currently not required for Assignment 3
    public void deleteVertex(Vertex v) {
        ArrayList<Edge> removals = new ArrayList<>();
        for (Edge e : edges) {
            if (e.start == v || e.end == v) {
                removals.add(e);
            }
        }
        for (Edge e : removals) {
            edges.remove(e);
        }
        vertices.remove(v);
        notifySubscribers();
    }

    public void addSubscriber(GraphModelListener aSubscriber) {
        subscribers.add(aSubscriber);
    }

    public void removeSubscriber(GraphModelListener aSubscriber) {
        subscribers.remove(aSubscriber);
    }

    private void notifySubscribers() {
        subscribers.forEach(sub -> sub.modelChanged());
    }

    public static double dist(double x1, double y1, double x2, double y2) {
        return Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));
    }
}
