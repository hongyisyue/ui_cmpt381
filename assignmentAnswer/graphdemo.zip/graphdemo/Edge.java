package graphdemo;

public class Edge {
    Vertex start, end;

    public Edge(Vertex newStart, Vertex newEnd) {
        start = newStart;
        end = newEnd;
    }
}
