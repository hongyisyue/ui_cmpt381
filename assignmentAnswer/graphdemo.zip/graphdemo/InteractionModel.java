package graphdemo;

import java.util.ArrayList;

public class InteractionModel {

    double portX, portY, portWidth, portHeight;
    Vertex selected;
    Vertex edgeSource;
    double lineEndX, lineEndY;
    ArrayList<GraphModelListener> subscribers;

    public InteractionModel() {
        portX = 0;
        portY = 0;
        portWidth = 0;
        portHeight = 0;
        selected = null;
        edgeSource = null;
        subscribers = new ArrayList<>();
    }

    public void setSelected(Vertex v) {
        selected = v;
        notifySubscribers();
    }

    public void setEdgeSource(Vertex newSource) {
        edgeSource = newSource;
        notifySubscribers();
    }

    public void setLineEnd(double newX, double newY) {
        lineEndX = newX;
        lineEndY = newY;
        notifySubscribers();
    }

    public void setPortWidth(double newWidth) {
        portWidth = newWidth;
        notifySubscribers();
    }

    public void setPortHeight(double newHeight) {
        portHeight = newHeight;
        notifySubscribers();
    }

    public boolean inViewport(double cx, double cy) {
        return cx >= portX && cx <= portX + portWidth && cy >= portY && cy <= portY + portHeight;
    }

    public void moveViewport(double dx, double dy) {
        // Note: all in model coordinates
        portX -= dx;
        portY -= dy;
        if (portX < 0) {
            portX = 0;
        }
        if (portY < 0) {
            portY = 0;
        }
        if (portX + portWidth > 1.0) {
            portX = 1.0 - portWidth;
        }
        if (portY + portHeight > 1.0) {
            portY = 1.0 - portHeight;
        }
        notifySubscribers();
    }

    public void addSubscriber(GraphModelListener aSubscriber) {
        subscribers.add(aSubscriber);
    }

    public void removeSubscriber(GraphModelListener aSubscriber) {
        subscribers.remove(aSubscriber);
    }

    private void notifySubscribers() {
        subscribers.forEach((sub) -> sub.modelChanged());
    }
}
