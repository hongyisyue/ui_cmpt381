package graphdemo;

import javafx.scene.paint.Color;

public class DetailView extends GraphView {

    public DetailView(double newWidth, double newHeight, double newLogicalWidth, double newLogicalHeight) {
        super(newWidth, newHeight);
        logicalWidth = newLogicalWidth;
        logicalHeight = newLogicalHeight;

        this.widthProperty().addListener((ov, old_val, new_val) -> resizeCanvas());
        this.heightProperty().addListener((ov, old_val, new_val) -> resizeCanvas());
    }

    public void resizeCanvas() {
        graphCanvas.setWidth(this.getWidth());
        graphCanvas.setHeight(this.getHeight());

        iModel.setPortWidth(getWidth() / logicalWidth);
        iModel.setPortHeight(getHeight() / logicalHeight);
    }

    public void draw() {
        // background
        gc.setFill(Color.GRAY);
        gc.fillRect(0, 0, getWidth(), getHeight());
        // graph (offset by port location)
        drawGraph(iModel.portX, iModel.portY);
    }
}
