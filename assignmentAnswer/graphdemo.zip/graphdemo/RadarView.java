package graphdemo;

import javafx.scene.paint.Color;

public class RadarView extends GraphView {

    public RadarView(double newWidth, double newHeight) {
        super(newWidth, newHeight);
    }

    public void draw() {
        // background
        gc.setFill(Color.LIGHTGRAY);
        gc.fillRect(0, 0, getWidth(), getHeight());

        drawViewRectangle();
        drawGraph(0,0);
    }

    public void drawViewRectangle() {
        gc.setFill(Color.CHARTREUSE);
        gc.fillRect(iModel.portX * graphCanvas.getWidth(), iModel.portY * graphCanvas.getHeight(),
                iModel.portWidth * graphCanvas.getWidth(), iModel.portHeight * graphCanvas.getHeight());
    }
}
