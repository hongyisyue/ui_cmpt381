package graphdemo;

public interface GraphModelListener {
    void modelChanged();
}
