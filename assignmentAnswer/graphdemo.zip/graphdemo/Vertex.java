package graphdemo;

public class Vertex {
    double x, y;
    double radius;
    int id;

    public Vertex(double newX, double newY, int newID) {
        x = newX;
        y = newY;
        id = newID;
        radius = 0.03;
    }

    public boolean contains(double sx, double sy) {
        return Graph.dist(x,y,sx,sy) <= radius;
    }

    public void move(double dx, double dy) {
        x += dx;
        y += dy;
    }
}
