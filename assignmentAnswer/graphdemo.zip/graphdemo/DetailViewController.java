package graphdemo;

import javafx.scene.input.MouseEvent;

public class DetailViewController {

    Graph model;
    DetailView view;
    InteractionModel iModel;

    int state;
    final int STATE_READY = 0;
    final int STATE_VERTEX_ARMED = 1;
    final int STATE_DRAGGING = 2;
    final int STATE_DRAWING_EDGE = 3;
    final int STATE_SWIPE = 4;
    final int STATE_BACKGROUND = 5;

    Vertex currentVertex;

    double modelX, modelY;
    double touchX, touchY;
    double prevTouchX, prevTouchY;
    double modelDX, modelDY;
    double touchDX, touchDY;

    public DetailViewController() {
        currentVertex = null;
        model = null;
        state = STATE_READY;
    }

    public void setModel(Graph aModel) {
        model = aModel;
    }

    public void setView(DetailView mgv) {
        view = mgv;
    }

    public void setInteractionModel(InteractionModel anIModel) {
        iModel = anIModel;
    }

    private void setMovementValues(MouseEvent event) {
        // calculate movement amounts in view and model coordinates
        // view coordinates:
        touchX = event.getX();
        touchY = event.getY();
        touchDX = touchX - prevTouchX;
        touchDY = touchY - prevTouchY;
        prevTouchX = touchX;
        prevTouchY = touchY;
        // model coordinates:
        modelX = event.getX() / view.logicalWidth + iModel.portX;
        modelY = event.getY() / view.logicalHeight + iModel.portY;
        modelDX = touchDX / view.logicalWidth;
        modelDY = touchDY / view.logicalHeight;
    }

    public void handleMousePressed(MouseEvent event) {
        setMovementValues(event);
        switch (state) {
            case STATE_READY:
                // prepare for drag or a start edge if we are on a vertex,
                // or a swipe if we are on the background
                if (model.contains(modelX, modelY)) {
                    if (event.isShiftDown()) {
                        // start edge
                        currentVertex = model.findClick(modelX, modelY);
                        iModel.setEdgeSource(currentVertex);
                        iModel.setLineEnd(modelX, modelY);
                        state = STATE_DRAWING_EDGE;
                    } else {
                        currentVertex = model.findClick(modelX, modelY);
                        iModel.setSelected(currentVertex);
                        state = STATE_VERTEX_ARMED;
                    }
                } else {
                    // on background, so start swipe or create
                    state = STATE_BACKGROUND;
                }
                break;
        }
    }

    public void handleMouseReleased(MouseEvent event) {
        setMovementValues(event);
        switch (state) {
            case STATE_BACKGROUND:
                // this is a creation action
                model.createVertex(modelX, modelY);
                state = STATE_READY;
                iModel.setSelected(null);
                break;
            case STATE_VERTEX_ARMED:
                // no drag started, and no long press occurred, so no-op
                currentVertex = null;
                state = STATE_READY;
                iModel.setSelected(null);
                break;
            case STATE_DRAGGING:
                // drag finished
                currentVertex = null;
                state = STATE_READY;
                iModel.setSelected(null);
                break;
            case STATE_DRAWING_EDGE:
                // temp edge finished, check for hit on vertex; if so, create edge
                if (model.contains(modelX, modelY)) {
                    model.createEdge(currentVertex, model.findClick(modelX, modelY));
                }
                currentVertex = null;
                iModel.setSelected(null);
                iModel.setEdgeSource(null);
                state = STATE_READY;
                break;
            case STATE_SWIPE:
                // swipe finished
                state = STATE_READY;
                break;
        }
    }

    public void handleMouseDragged(MouseEvent event) {
        setMovementValues(event);
        switch (state) {
            case STATE_BACKGROUND:
                // start a swipe
                state = STATE_SWIPE;
                iModel.moveViewport(modelDX, modelDY);
                break;
            case STATE_SWIPE:
                // continue swipe
                iModel.moveViewport(modelDX, modelDY);
                break;
            case STATE_VERTEX_ARMED:
                // switch to dragging and start moving
                state = STATE_DRAGGING;
                model.moveVertex(currentVertex, modelDX, modelDY);
                break;
            case STATE_DRAGGING:
                // continue dragging vertex
                model.moveVertex(currentVertex, modelDX, modelDY);
                break;
            case STATE_DRAWING_EDGE:
                // continue temporary edge line
                iModel.setLineEnd(modelX, modelY);
                break;
        }
    }
}
