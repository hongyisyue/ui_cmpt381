package com.example.gutwin.shapeeditor;

import java.util.ArrayList;

/**
 * Created by gutwin on 2018-02-16.
 */

public class InteractionModel {

    Triangle selected;
    ArrayList<TriangleModelListener> subscribers;

    public InteractionModel() {
        selected = null;
        subscribers = new ArrayList<>();
    }

    public void setSelected(Triangle b) {
        selected = b;
        notifySubscribers();
    }

    public void addSubscriber(TriangleModelListener aSubscriber) {
        subscribers.add(aSubscriber);
    }

    public void removeSubscriber(TriangleModelListener aSubscriber) {
        subscribers.remove(aSubscriber);
    }

    private void notifySubscribers() {
        for (TriangleModelListener tml : subscribers) {
            tml.modelUpdated();
        }
    }
}
