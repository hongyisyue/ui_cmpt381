package com.example.gutwin.shapeeditor;

import android.util.Log;
import android.view.MotionEvent;
import android.view.View;

/**
 * Created by gutwin on 2018-02-16.
 */

public class TriangleViewController implements View.OnTouchListener {
    TriangleModel model;
    InteractionModel iModel;

    int state;
    final int STATE_READY = 0;
    final int STATE_DRAGGING = 1;
    final int STATE_SELECTED = 2;
    final int STATE_SCALING = 3;
    final int STATE_ROTATING = 4;

    float prevX, prevY, dX, dY;
    double prevAngle;

    public TriangleViewController() {

    }

    public void setModel(TriangleModel aModel) {
        model = aModel;
    }

    public void setInteractionModel(InteractionModel anIModel) {
        iModel = anIModel;
    }

    @Override
    public boolean onTouch(View v, MotionEvent event) {
        //Log.d("Controller", "action is: " + event.getAction());
        switch (state) {
            case STATE_READY:
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        if (model.contains(event.getX(), event.getY())) {
                            iModel.setSelected(model.find(event.getX(), event.getY()));
                            Log.d("Controller", "setting selected to triangle");
                            prevX = event.getX();
                            prevY = event.getY();
                            state = STATE_DRAGGING;
                        }
                        break;
                }
                break;
            case STATE_SELECTED:
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        if (model.hitScaleHandle(iModel.selected,event.getX(), event.getY())) {
                            // on scale handle
                            Log.d("Controller", "setting state to scaling");
                            prevX = event.getX();
                            prevY = event.getY();
                            state = STATE_SCALING;
                        } else if (model.hitRotateHandle(iModel.selected,event.getX(), event.getY())) {
                            // on rotate handle
                            Log.d("Controller", "setting state to rotating");
                            prevX = event.getX();
                            prevY = event.getY();
                            prevAngle = model.getAngle(iModel.selected, event.getX(), event.getY());
                            Log.d("Controller", "click angle is: " + prevAngle);
                            state = STATE_ROTATING;
                        } else if (model.contains(event.getX(), event.getY())) {
                            // on a triangle
                            iModel.setSelected(model.find(event.getX(), event.getY()));
                            Log.d("Controller", "setting selected to triangle");
                            prevX = event.getX();
                            prevY = event.getY();
                            state = STATE_DRAGGING;
                        } else if (!model.contains(event.getX(), event.getY())) {
                            // on background
                            iModel.setSelected(null);
                            Log.d("Controller", "setting selected null");
                            state = STATE_READY;
                        }
                    break;
                }
                break;
            case STATE_DRAGGING:
                switch (event.getAction()) {
                    case MotionEvent.ACTION_MOVE:
                        dX = event.getX() - prevX;
                        dY = event.getY() - prevY;
                        prevX = event.getX();
                        prevY = event.getY();
                        //Log.d("Controller", "action_move: " + dX + "," + dY);
                        model.moveTriangle(iModel.selected, dX, dY);

                        break;
                    case MotionEvent.ACTION_UP:
                        state = STATE_SELECTED;
                        break;
                }
                break;
            case STATE_SCALING:
                switch (event.getAction()) {
                    case MotionEvent.ACTION_MOVE:
                        dX = event.getX() - prevX;
                        dY = event.getY() - prevY;
                        prevX = event.getX();
                        prevY = event.getY();
                        //Log.d("Controller", "action_move: " + dX + "," + dY);
                        model.scaleTriangle(iModel.selected, dX, dY);
                        break;
                    case MotionEvent.ACTION_UP:
                        state = STATE_SELECTED;
                        break;
                }
                break;
            case STATE_ROTATING:
                switch (event.getAction()) {
                    case MotionEvent.ACTION_MOVE:
                        model.rotateTriangle(iModel.selected, event.getX(), event.getY());
                        Log.d("Controller", "click angle is: " + prevAngle);
                        break;
                    case MotionEvent.ACTION_UP:
                        state = STATE_SELECTED;
                        break;
                }
                break;
        }
        Log.d("Controller", "state is: " + state);

        return true;
    }
}
