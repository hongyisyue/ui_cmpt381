package com.example.gutwin.shapeeditor;

import android.app.Activity;
import android.os.Bundle;
import android.widget.LinearLayout;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_main);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        TriangleView view = new TriangleView(this, null);
        root.addView(view);

        TriangleModel model = new TriangleModel();
        TriangleViewController controller = new TriangleViewController();
        InteractionModel iModel = new InteractionModel();
        view.setInteractionModel(iModel);
        view.setModel(model);
        model.addSubscriber(view);
        iModel.addSubscriber(view);
        controller.setModel(model);
        controller.setInteractionModel(iModel);

        // events
        view.setOnTouchListener(controller);


        setContentView(root);

    }
}
