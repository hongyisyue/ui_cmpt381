package com.example.gutwin.shapeeditor;

import java.util.ArrayList;

/**
 * Created by gutwin on 2018-02-16.
 */

public class TriangleModel {

    ArrayList<Triangle> triangles;
    ArrayList<TriangleModelListener> subscribers;

    public TriangleModel() {
        triangles = new ArrayList<>();
        subscribers = new ArrayList<>();
        addTriangle(100,100,380,250, 190, 400);
        addTriangle(500,700,900,800, 600, 900);
        addTriangle(300,1100,500,1300, 300, 1300);
    }

    public void addTriangle(float x1, float y1, float x2, float y2, float x3, float y3) {
        triangles.add(new Triangle(x1, y1, x2, y2, x3, y3));
        notifySubscribers();
    }

    public void addSubscriber(TriangleModelListener aSub) {
        subscribers.add(aSub);
    }

    private void notifySubscribers() {
        for (TriangleModelListener tml : subscribers) {
            tml.modelUpdated();
        }
    }

    public boolean contains(float x, float y) {
        boolean found = false;
        for (Triangle b : triangles) {
            if (b.contains(x, y)) {
                found = true;
            }
        }
        return found;
    }

    public Triangle find(float x, float y) {
        Triangle target = null;
        for (Triangle b : triangles) {
            if (b.contains(x, y)) {
                target = b;
            }
        }
        return target;
    }

    public void moveTriangle(Triangle t, float dx, float dy) {
        if (t != null) {
            t.translate(dx,dy);
        }
        notifySubscribers();
    }

    public boolean hitScaleHandle(Triangle t, float x, float y) {
        return t.hitScaleHandle(x,y);
    }

    public boolean hitRotateHandle(Triangle t, float x, float y) {
        return t.hitRotateHandle(x,y);
    }

    public void scaleTriangle(Triangle t, float dx, float dy) {
        if (t != null) {
            t.scale(dx,dy);
        }
        notifySubscribers();
    }

    public void rotateTriangle(Triangle t, float x, float y) {
        if (t != null) {
            t.rotate(x,y);
        }
        notifySubscribers();
    }

    public double getAngle(Triangle t, float dx, float dy) {
        if (t != null) {
            return t.getAngle(dx,dy);
        } else {
            return 0.0;
        }
    }
}
