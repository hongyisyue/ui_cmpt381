package com.example.gutwin.shapeeditor;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.Log;

/**
 * Created by gutwin on 2018-02-16.
 */

public class Triangle {
    float x1, y1, x2, y2, x3, y3;
    float px1, py1, px2, py2, px3, py3;
    Path outline, bbox;
    float left, top, right, bottom;
    float translateX, translateY;
    double scaleX, scaleY;
    double rotation;
    float handleRadius;
    float pLeft,pTop,pRight,pBottom;
    float bbx1, bby1, bbx2, bby2, bbx3, bby3, bbx4, bby4;



    public Triangle(float newX1, float newY1, float newX2, float newY2, float newX3, float newY3) {
        calculateBounds(newX1, newY1, newX2, newY2, newX3, newY3);
        translateX = left + (right - left) / 2;
        translateY = top + (bottom - top) / 2;
        // adjust bounds by translation
        left -= translateX;
        right -= translateX;
        top -= translateY;
        bottom -= translateY;

        bbx1 = left;
        bby1 = top;
        bbx2 = right;
        bby2 = top;
        bbx3 = right;
        bby3 = bottom;
        bbx4 = left;
        bby4 = bottom;

        Log.d("Triangle", "tX and tY are " + translateX + "," + translateY);
        scaleX = 1.0;
        scaleY = 1.0;

        rotation = 0.0;

        x1 = newX1 - translateX;
        y1 = newY1 - translateY;
        x2 = newX2 - translateX;
        y2 = newY2 - translateY;
        x3 = newX3 - translateX;
        y3 = newY3 - translateY;

        outline = new Path();
        bbox = new Path();
        calculateDisplayCoords();

        handleRadius = 20;
    }

    private void calculateBounds(float xa, float ya, float xb, float yb, float xc, float yc) {
        left = Math.min(xa, Math.min(xb, xc));
        right = Math.max(xa, Math.max(xb, xc));
        top = Math.min(ya, Math.min(yb, yc));
        bottom = Math.max(ya, Math.max(yb, yc));
    }

    // Utility function to calculate area of triangle formed by (x1, y1) (x2, y2) and (x3, y3)
    private float area(float xa, float ya, float xb, float yb, float xc, float yc) {
        return (float) Math.abs((xa * (yb - yc) + xb * (yc - ya) + xc * (ya - yb)) / 2.0);
    }

    // Function to check whether point P(x, y) lies inside the triangle formed by
    // A(x1, y1), B(x2, y2), and C(x3, y3)
    public boolean contains(float x, float y) {
        // Calculate area of triangle ABC
        float a = area(px1, py1, px2, py2, px3, py3);

        // Calculate area of triangle PBC
        float a1 = area(x, y, px2, py2, px3, py3);

        // Calculate area of triangle PAC
        float a2 = area(px1, py1, x, y, px3, py3);

        // Calculate area of triangle PAB
        float a3 = area(px1, py1, px2, py2, x, y);

        Log.d("Triangle", "diff of A and A1+A2+A3: " + (a - (a1 + a2 + a3)));

        // Check if sum of A1, A2 and A3 are close
        return (Math.abs(a - (a1 + a2 + a3)) < 1);
    }

    public void translate(float dx, float dy) {
        translateX += dx;
        translateY += dy;

        calculateDisplayCoords();
    }

    public void scale(float dx, float dy) {
        // find scale such that the handle moves by exactly dx,dy
        double newScaleX = (left + dx) / left;
        double newScaleY = (top + dy) / top;
        double scaleDX = newScaleX - 1.0;
        double scaleDY = newScaleY - 1.0;
        scaleX += scaleDX;
        scaleY += scaleDY;
        //Log.d("Triangle", "left: " + left + "     dx, dy: " + dx + "," + dy + "      new scale: " + scaleX + "," + scaleY);

        calculateDisplayCoords();
    }

    private float transformX(float x, float y) {
        // rotate
        x = (float)Math.cos(rotation) * x - (float)Math.sin(rotation) * y;
        // scale
        x = x * (float)scaleX;
        // translate
        x += translateX;
        return x;
    }

    private float transformY(float y, float x) {
        // rotate
        y = (float)Math.sin(rotation) * x + (float)Math.cos(rotation) * y;
        // scale
        y = y * (float)scaleY;
        // translate
        y += translateY;
        return y;
    }

    public void calculateDisplayCoords() {
        px1 = transformX(x1,y1);
        px2 = transformX(x2,y2);
        px3 = transformX(x3,y3);
        py1 = transformY(y1,x1);
        py2 = transformY(y2,x2);
        py3 = transformY(y3,x3);
        pLeft = transformX(left,top);
        pRight = transformX(right,bottom);
        pTop = transformY(top,left);
        pBottom = transformY(bottom,right);
        bbx1 = transformX(left,top);
        bby1 = transformY(top,left);
        bbx2 = transformX(right,top);
        bby2 = transformY(top,right);
        bbx3 = transformX(right,bottom);
        bby3 = transformY(bottom,right);
        bbx4 = transformX(left,bottom);
        bby4 = transformY(bottom,left);
        Log.d("Triangle", "new pLeft: " + pLeft);

    }

    public void drawNormal(Canvas c, Paint p) {
        outline.rewind();
        outline.moveTo(px1, py1);
        outline.lineTo(px2, py2);
        outline.lineTo(px3, py3);
        outline.lineTo(px1, py1);
        outline.close();

        c.drawPath(outline, p);

        //rotation += 0.1;
    }

    public void drawSelected(Canvas c, Paint p) {
        // first draw normal
        drawNormal(c,p);

        // draw bbox
        p.setColor(Color.WHITE);
        p.setStyle(Paint.Style.STROKE);
        //c.drawRect(pLeft, pTop, pRight, pBottom, p);
        bbox.rewind();
        bbox.moveTo(bbx1,bby1);
        bbox.lineTo(bbx2,bby2);
        bbox.lineTo(bbx3,bby3);
        bbox.lineTo(bbx4,bby4);
        bbox.lineTo(bbx1,bby1);
        bbox.close();
        c.drawPath(bbox,p);
        // draw scale handle
        p.setColor(Color.parseColor("yellow"));
        p.setStyle(Paint.Style.FILL);
        c.drawOval(pLeft-handleRadius,pTop-handleRadius,pLeft+handleRadius,pTop+handleRadius,p);
        // draw rotate handle
        p.setColor(Color.parseColor("lime"));
        c.drawOval(pRight-handleRadius,pBottom-handleRadius,pRight+handleRadius,pBottom+handleRadius,p);

        p.setColor(Color.WHITE);
        p.setTextSize(40);
        c.drawText("TX: " + String.format("%.0f",translateX), 20,50,p);
        c.drawText("TY: " + String.format("%.0f",translateY), 20,100,p);
        c.drawText("SX: " + String.format("%.2f",scaleX), 20,150,p);
        c.drawText("SY: " + String.format("%.2f",scaleY), 20,200,p);
        c.drawText("A: " + String.format("%.2f",rotation), 20,250,p);
    }

    public boolean hitScaleHandle(float x, float y) {
        return handleRadius > Math.sqrt(Math.pow(x - pLeft, 2) + Math.pow(y - pTop, 2));
    }

    public boolean hitRotateHandle(float x, float y) {
        return handleRadius > Math.sqrt(Math.pow(x - pRight, 2) + Math.pow(y - pBottom, 2));
    }

    public double getAngle(float x, float y) {
        //Math.toDegrees(Math.atan2(yDiff, xDiff));
        x -= translateX;
        y -= translateY;
        return Math.atan2(y, x);
    }

    public void rotate(float x, float y) {
        x -= translateX;
        y -= translateY;
        rotation = Math.atan2(y, x) - Math.PI / 4;
        calculateDisplayCoords();
    }
}
