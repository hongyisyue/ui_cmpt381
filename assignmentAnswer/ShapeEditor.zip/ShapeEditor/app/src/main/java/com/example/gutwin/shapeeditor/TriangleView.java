package com.example.gutwin.shapeeditor;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

/**
 * Created by gutwin on 2018-02-16.
 */

public class TriangleView extends View implements TriangleModelListener {
    Paint myPaint;
    TriangleModel model;
    InteractionModel iModel;

    public TriangleView(Context context, AttributeSet attrs) {
        super(context, attrs);
        setBackgroundColor(Color.rgb(80, 50, 110));
        myPaint = new Paint();
    }

    public void setModel(TriangleModel aModel) {
        model = aModel;
    }

    public void setInteractionModel(InteractionModel anIModel) {
        iModel = anIModel;
    }

    protected void onDraw(Canvas myCanvas) {
        //myPaint.setColor(Color.GREEN);
        myPaint.setStyle(Paint.Style.FILL);
        //myCanvas.drawRect(100, 300, 400, 500, myPaint);

        myPaint.setStyle(Paint.Style.FILL);
        for (Triangle t : model.triangles) {
            if (t == iModel.selected) {
                myPaint.setColor(Color.MAGENTA);
                t.drawSelected(myCanvas,myPaint);
            } else {
                myPaint.setColor(Color.parseColor("teal"));
                t.drawNormal(myCanvas,myPaint);
            }
        }
    }

    public void modelUpdated() {
        this.invalidate();
    }
}
