package com.example.gutwin.shapeeditor;

/**
 * Created by gutwin on 2018-02-16.
 */

public interface TriangleModelListener {
    public void modelUpdated();
}
