/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package midtermbasicui;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 *
 * @author gutwin
 */
public class MidtermBasicUI extends Application {    
    @Override
    public void start(Stage primaryStage) {
        Label aLabel = new Label("A Label");
        TextField aField = new TextField();
        Button aButton = new Button("Change Text");
        
        aButton.setMaxWidth(Double.MAX_VALUE);
        aButton.setOnAction(e -> aLabel.setText(aField.getText()));
        
        HBox row = new HBox(aLabel,aField);
        VBox root = new VBox(row,aButton);
        Scene scene = new Scene(root);
        
        primaryStage.setTitle("CMPT 381");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }    
}
