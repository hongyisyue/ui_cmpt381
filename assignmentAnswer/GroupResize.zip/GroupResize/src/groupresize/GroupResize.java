/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package groupresize;

import java.util.ArrayList;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

/**
 *
 * @author gutwin
 */
public class GroupResize extends Application {

    Model myModel;
    View myView;

    @Override
    public void start(Stage primaryStage) {
        myView = new View();
        myModel = new Model();
        Controller myController = new Controller();

        Button b1 = new Button("Group");
        Button b2 = new Button("Ungroup");
        b1.setOnAction(myController::groupClick);
        b2.setOnAction(myController::ungroupClick);
        myView.setOnMousePressed(myController::handleMousePressed);
        myView.setOnMouseDragged(myController::handleMouseDragged);
        myView.setOnMouseReleased(myController::handleMouseReleased);

        HBox root = new HBox(b1, myView, b2);
        Scene scene = new Scene(root);

        primaryStage.setScene(scene);
        primaryStage.show();

        myView.draw();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

    class Model {

        Box box1, box2;
        ArrayList<Groupable> groups;
        Group myGroup;

        public Model() {
            groups = new ArrayList<>();
            box1 = new Box(50, 100, 100, 200);
            box2 = new Box(200, 300, 200, 100);
            groups.add(box1);
            groups.add(box2);
            myGroup = new Group(groups);
        }

        public void resize(double dx, double dy) {
            groups.forEach(g -> g.resize(dx, dy));
            myView.draw();
        }

        public void group() {
            groups.clear();
            groups.add(myGroup);
            myGroup.recalculateBounds();
            myView.draw();
        }

        public void ungroup() {
            groups.clear();
            groups.add(box1);
            groups.add(box2);
            myView.draw();
        }
    }

    class View extends Pane {

        GraphicsContext gc;

        public View() {
            Canvas boxCanvas = new Canvas(600, 600);
            gc = boxCanvas.getGraphicsContext2D();
            getChildren().add(boxCanvas);
        }

        public void draw() {
            // background
            gc.setFill(Color.LIGHTGREY);
            gc.fillRect(0, 0, 600, 600);

            // items
            myModel.groups.forEach(g -> draw(g));
        }

        private void draw(Groupable g) {
            if (g.hasChildren()) {
                // group

                // draw bbox
                gc.setStroke(Color.RED);
                gc.strokeRect(g.getLeft(), g.getTop(), g.getRight() - g.getLeft(), 
                        g.getBottom() - g.getTop());
                // draw children
                g.getChildren().forEach(c -> draw(c));
            } else {
                // box
                gc.setFill(Color.BLUE);
                gc.fillRect(g.getLeft(), g.getTop(), g.getRight() - g.getLeft(), 
                        g.getBottom() - g.getTop());
                gc.setStroke(Color.WHITE);
                gc.strokeRect(g.getLeft(), g.getTop(), g.getRight() - g.getLeft(), 
                        g.getBottom() - g.getTop());
            }
        }
    }

    class Controller {

        double prevX, prevY, dX, dY;

        public void groupClick(ActionEvent event) {
            myModel.group();
        }

        public void ungroupClick(ActionEvent event) {
            myModel.ungroup();
        }

        public void handleMousePressed(MouseEvent event) {
            prevX = event.getX();
            prevY = event.getY();
        }

        public void handleMouseDragged(MouseEvent event) {
            dX = event.getX() - prevX;
            dY = event.getY() - prevY;
            myModel.resize(dX, dY);
            prevX = event.getX();
            prevY = event.getY();
        }

        public void handleMouseReleased(MouseEvent event) {

        }

    }

    interface Groupable {

        public boolean hasChildren();

        public ArrayList<Groupable> getChildren();

        void resize(double dX, double dY);
        
        void ratioResize(double rX, double rY, double parentX, double parentY);

        double getLeft();

        double getRight();

        double getTop();

        double getBottom();
    }

    class Group implements Groupable {

        ArrayList<Groupable> groups;
        BoundingBox bbox;

        public Group(ArrayList<Groupable> gs) {
            groups = new ArrayList<>();
            gs.forEach(g -> groups.add(g));
            bbox = new BoundingBox();
            recalculateBounds();
        }

        private void recalculateBounds() {

            bbox.left = Double.MAX_VALUE;
            bbox.top = Double.MAX_VALUE;
            bbox.right = 0;
            bbox.bottom = 0;

            groups.forEach(g -> {
                bbox.left = Math.min(bbox.left, g.getLeft());
                bbox.right = Math.max(bbox.right, g.getRight());
                bbox.top = Math.min(bbox.top, g.getTop());
                bbox.bottom = Math.max(bbox.bottom, g.getBottom());
            });
        }
        
        public void resize(double dx, double dy) {
            double width = bbox.right - bbox.left;
            double ratioX = (width+dx) / width;
            double height = bbox.bottom - bbox.top;
            double ratioY = (height+dy) / height;
            
            ratioResize(ratioX, ratioY, bbox.left, bbox.top);
            recalculateBounds();
        }
        
        public void ratioResize(double rX, double rY, double parentX, double parentY) {
            groups.forEach(g -> g.ratioResize(rX, rY, parentX, parentY));
        }

        public double getLeft() {
            return bbox.left;
        }

        public double getRight() {
            return bbox.right;
        }

        public double getTop() {
            return bbox.top;
        }

        public double getBottom() {
            return bbox.bottom;
        }
        
        public boolean hasChildren() {
            return true;
        }

        public ArrayList<Groupable> getChildren() {
            return groups;
        }


    }

    class BoundingBox {

        double left, top, right, bottom;
    }

    class Box implements Groupable {

        double x, y, width, height;

        public Box(double newX, double newY, double newW, double newH) {
            x = newX;
            y = newY;
            width = newW;
            height = newH;
        }

        public void resize(double dx, double dy) {
            //width = width + dx;
            //height = height + dy;
            
        }
        
        public void ratioResize(double rX, double rY, double parentX, double parentY) {
            width = width * rX;
            height = height * rY;
            x = (x - parentX) * rX + parentX;
            y = (y - parentY) * rY + parentY;
        }

        public boolean hasChildren() {
            return false;
        }

        public ArrayList<Groupable> getChildren() {
            return null;
        }

        public double getLeft() {
            return x;
        }

        public double getRight() {
            return x + width;
        }

        public double getTop() {
            return y;
        }

        public double getBottom() {
            return y + height;
        }
    }
}
