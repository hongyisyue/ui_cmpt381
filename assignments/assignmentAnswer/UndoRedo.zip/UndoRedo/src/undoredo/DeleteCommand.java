/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package undoredo;

import undoredo.TextCommand;
import undoredo.TextModel;

/**
 *
 * @author alixgoguey
 */
public class DeleteCommand implements TextCommand {
    TextModel model;
    int start_pos;
    int end_pos;
    String str;
    
    public DeleteCommand(TextModel _model, int _start_pos, int _end_pos) {
        model = _model;
        start_pos = _start_pos;
        end_pos = _end_pos;
        str = model.get_text(start_pos, end_pos);
    }
    
    public void doIt() {
        model.delete_text(start_pos, end_pos);
    }
    
    public void undo() {
        model.insert_text(start_pos, str);
    }
    
    public String toString() {
        return "DeleteCmd: delete "+str+" from "+start_pos+" to "+end_pos;
    }
}
