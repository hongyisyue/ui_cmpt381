/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package undoredo;

/**
 *
 * @author alixgoguey
 */
public class InsertCommand implements TextCommand {
    TextModel model;
    int start_pos;
    String str;
    
    public InsertCommand(TextModel _model, int _start_pos, String _str) {
        model = _model;
        start_pos = _start_pos;
        str = _str;
    }
    
    public void doIt() {
        model.insert_text(start_pos, str);
    }
    
    public void undo() {
        model.delete_text(start_pos, start_pos+str.length()-1);
    }
    
    public String toString() {
        return "InsertCmd: insert "+str+" at "+start_pos;
    }
}
