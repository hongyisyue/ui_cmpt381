/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package undoredo;

/**
 *
 * @author alixgoguey
 */
public class TextModel {
    String text = "";
    int caret = 0;
    
    public void insert_text(int start_pos, String str) {
        text = text.substring(0, start_pos) + str + text.substring(start_pos, text.length());
        caret = start_pos + str.length();
    }
    
    public void delete_text(int start_pos, int end_pos) {
        if (end_pos >= text.length()) {
            text = text.substring(0, start_pos);
        } else {
            text = text.substring(0, start_pos) + text.substring(end_pos + 1, text.length());
        }
        caret = start_pos;
    }
    
    public void shift_caret(int val) {
        caret += val;
        if (caret < 0) { caret = 0; }
        if (caret > text.length()) { caret = text.length(); }
    }
    
    public String get_text(int start_pos, int end_pos) {
        return text.substring(start_pos, end_pos+1);
    }
}
